-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 11:17 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reglog`
--

-- --------------------------------------------------------

--
-- Table structure for table `stk_entry`
--

CREATE TABLE `stk_entry` (
  `stkid` int(4) NOT NULL,
  `stkname` varchar(50) NOT NULL,
  `stkquantity` varchar(10) NOT NULL,
  `stkvendor` varchar(50) NOT NULL,
  `stkprice` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stk_entry`
--

INSERT INTO `stk_entry` (`stkid`, `stkname`, `stkquantity`, `stkvendor`, `stkprice`) VALUES
(1001, 'answersheets', '40', 'akhil book store', 250),
(1010, 'Markers', '25', 'krishna books shop', 250),
(1012, 'answersheets', '25', 'akhil book store', 420),
(1019, 'Packing Threads', '20', 'akhil book store', 420),
(1020, 'files', '25', 'krishna books shop', 250);

-- --------------------------------------------------------

--
-- Table structure for table `stocktable`
--

CREATE TABLE `stocktable` (
  `stock_id` int(4) NOT NULL,
  `stock_name` varchar(50) NOT NULL,
  `remaining_quantity` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stocktable`
--

INSERT INTO `stocktable` (`stock_id`, `stock_name`, `remaining_quantity`) VALUES
(1001, 'Main Answer sheets', 20),
(1002, 'Additional Papers', 20),
(1003, 'Packing Covers', 25),
(1004, 'Cloth Covers For Packing Purpose', 30),
(1005, 'Thread Bundles', 30),
(1006, 'White Papers', 20),
(1007, 'Color papers', 10),
(1008, 'A4-Sheet Bundles', 20),
(1009, 'Graph Sheets', 20),
(1010, 'Markers', 20),
(1011, 'Packing Threads', 20),
(1012, 'Tapes-White&Brown', 20),
(1013, 'Chalk-Piece', 40),
(1014, 'Files', 25),
(1015, 'Pens', 20),
(1016, 'Rubbers', 40),
(1017, 'Scales', 20),
(1018, 'Stamp Pads', 40),
(1019, 'Sealing Wax', 20),
(1020, 'Binder Clips', 20),
(1021, 'Calculator', 20),
(1022, 'Gum Bottle', 20);

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'ninza', 'admin', 'admin@gmail.com', '123'),
(2, 'manju', '47', 'manju@gmail.com', '4700');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stk_entry`
--
ALTER TABLE `stk_entry`
  ADD PRIMARY KEY (`stkid`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
